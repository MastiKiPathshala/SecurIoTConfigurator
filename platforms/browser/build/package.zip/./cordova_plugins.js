cordova.define('cordova/plugin_list', function(require, exports, module) {
module.exports = [
    {
        "file": "plugins/com.pylonproducts.wifiwizard/www/WifiWizard.js",
        "id": "com.pylonproducts.wifiwizard.WifiWizard",
        "pluginId": "com.pylonproducts.wifiwizard",
        "clobbers": [
            "window.WifiWizard"
        ]
    },
    {
        "file": "plugins/cordova-plugin-device/www/device.js",
        "id": "cordova-plugin-device.device",
        "pluginId": "cordova-plugin-device",
        "clobbers": [
            "device"
        ]
    },
    {
        "file": "plugins/cordova-plugin-device/src/browser/DeviceProxy.js",
        "id": "cordova-plugin-device.DeviceProxy",
        "pluginId": "cordova-plugin-device",
        "runs": true
    },
    {
        "file": "plugins/cordova-plugin-hotspot/www/HotSpotPlugin.js",
        "id": "cordova-plugin-hotspot.HotSpotPlugin",
        "pluginId": "cordova-plugin-hotspot",
        "clobbers": [
            "cordova.plugins.hotspot"
        ]
    }
];
module.exports.metadata = 
// TOP OF METADATA
{
    "com.pylonproducts.wifiwizard": "0.2.11",
    "cordova-plugin-android-permissions": "0.10.0",
    "cordova-plugin-compat": "1.0.0",
    "cordova-plugin-console": "1.0.3",
    "cordova-plugin-device": "1.1.4",
    "cordova-plugin-hotspot": "1.2.5",
    "cordova-plugin-whitelist": "1.2.2",
    "cordova.plugins.diagnostic": "3.1.0"
}
// BOTTOM OF METADATA
});